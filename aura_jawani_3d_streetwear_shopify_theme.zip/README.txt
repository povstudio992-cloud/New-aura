AURA JAWANI — Shopify Online Store 2.0 theme starter
Install: Shopify Admin > Online Store > Themes > Add theme > Upload zip file.
Then add products to the Frontpage collection and select it in the AURA products section.
Includes responsive dark streetwear design, animated CSS 3D clothing rack, pointer tilt,
and Shopify collection product cards. Rack garments are decorative CSS illustrations;
real products appear in the product grid. Configure payments, shipping, taxes, policies,
domain and product details in Shopify Admin before launch. Preview and test before publishing.