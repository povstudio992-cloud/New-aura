# AURA JAWANI — ecommerce starter

This is a complete, GitHub Pages-friendly storefront starter with:
- Home, shop, cart, checkout, customer login/signup, admin UI and policy pages
- Shared styling and JavaScript
- Supabase SQL schema for products, profiles and orders
- A Supabase Edge Function starter for creating Stripe Checkout sessions

## Important: what is and is not live
The website UI works as a static site. The cart uses browser local storage.
Customer authentication, shared product inventory, order storage and payments become real only after you configure Supabase and Stripe and deploy the Edge Function. Do not accept real orders until this setup and testing are complete.

## 1. Upload to GitHub
1. Create/open your GitHub repository.
2. Upload all files and folders from this project (keep the folder structure).
3. In GitHub, open **Settings → Pages**.
4. Select your deployment branch and `/ (root)`, then save.
5. Open the published URL.

## 2. Configure Supabase
1. Create a Supabase project.
2. Open **SQL Editor** and run `supabase/schema.sql`.
3. In `assets/config.js`, replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY`.
4. The anon key is intended for browser use only; never put a service-role key in frontend files.
5. Configure Supabase Auth email settings and allowed redirect URLs for your GitHub Pages URL and custom domain.

## 3. Configure Stripe payments
1. Create a Stripe account and complete the business/identity requirements.
2. Deploy `supabase/functions/create-checkout/index.ts` as a Supabase Edge Function.
3. Set the Edge Function secrets: `STRIPE_SECRET_KEY` and `SITE_URL`.
4. Add your Supabase project URL and anon key to `assets/config.js`.
5. Update the function's allowed product/order logic before launch. Test with Stripe test keys first.
6. Set up a Stripe webhook to mark orders paid only after Stripe confirms payment. Never mark an order paid based only on a browser redirect.

PayPal is shown as a future option in the UI but is not connected in this starter. Connect it through a trusted server-side integration before enabling it.

## 4. Admin access
The admin page checks for a signed-in Supabase user and an `admin` role in `profiles`.
After creating your customer account, use the Supabase SQL Editor to grant admin to your own user UUID:
```sql
update public.profiles
set role = 'admin'
where id = 'YOUR_AUTH_USER_UUID';
```
Do not expose admin credentials in HTML. RLS policies are included in the schema.

## 5. Before launch
- Replace demo products and imagery with your own product photos and accurate stock/prices.
- Configure shipping rates, VAT/tax, returns, privacy, terms and contact details for the countries you sell to.
- Test mobile layout, account flows, stock handling, checkout, refunds and order emails.
- Add a real domain in GitHub Pages and Supabase Auth redirect settings.
- Do not collect or store card numbers on your website. Stripe-hosted Checkout handles card details.

This is a starter implementation, not legal, tax or payment-provider advice.
