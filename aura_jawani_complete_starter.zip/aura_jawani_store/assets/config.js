// Public browser configuration only. Never place a Supabase service-role key here.
export const SUPABASE_URL = "YOUR_SUPABASE_URL";
export const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
export const CURRENCY = "EUR";
export const DEMO_PRODUCTS = [
 {id:"demo-tee",name:"Essential Oversized Tee",price:39.99,category:"T-shirts",image_url:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=900",description:"A relaxed everyday essential.",stock:20},
 {id:"demo-hoodie",name:"Signature Street Hoodie",price:69.99,category:"Hoodies",image_url:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=900",description:"Premium comfort with a streetwear attitude.",stock:12},
 {id:"demo-cargo",name:"Urban Cargo Pants",price:59.99,category:"Pants",image_url:"https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=900",description:"Utility-inspired relaxed fit.",stock:10}
];
