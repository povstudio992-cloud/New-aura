// Supabase Edge Function starter. Deploy with Stripe secret configured.
// Required secrets: STRIPE_SECRET_KEY, SUPABASE_URL, SUPABASE_ANON_KEY, SITE_URL
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import Stripe from "https://esm.sh/stripe@14?target=deno";

const cors = {
  "Access-Control-Allow-Origin": Deno.env.get("SITE_URL") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Authentication required");
    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) throw new Error("Please sign in before checkout");

    const body = await req.json();
    const customer = body.customer ?? {};
    const items = Array.isArray(body.items) ? body.items : [];
    if (!items.length) throw new Error("Cart is empty");

    // Never trust browser prices: fetch product IDs and prices from the database.
    const ids = items.map((i: {id:string}) => i.id).filter((id: string) => !id.startsWith("demo-"));
    if (ids.length !== items.length) throw new Error("Demo products cannot be purchased. Add real products in the admin panel first.");
    const { data: dbProducts, error: productsError } = await supabase
      .from("products").select("id,name,price,stock,active").in("id", ids);
    if (productsError || !dbProducts || dbProducts.length !== items.length) throw new Error("One or more products are unavailable");

    const lineItems = items.map((item: {id:string,quantity:number}) => {
      const p = dbProducts.find((x: any) => x.id === item.id);
      const qty = Math.max(1, Math.min(20, Math.floor(Number(item.quantity))));
      if (!p || !p.active || p.stock < qty) throw new Error("Product is out of stock");
      return { price_data: { currency: "eur", product_data: { name: p.name }, unit_amount: Math.round(Number(p.price) * 100) }, quantity: qty };
    });

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, { apiVersion: "2023-10-16" });
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: lineItems,
      customer_email: String(customer.email || user.email),
      success_url: `${Deno.env.get("SITE_URL")}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${Deno.env.get("SITE_URL")}/checkout.html`,
      metadata: { user_id: user.id }
    });
    return new Response(JSON.stringify({ url: session.url }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: err instanceof Error ? err.message : "Checkout error" }), {
      status: 400, headers: { ...cors, "Content-Type": "application/json" }
    });
  }
});
